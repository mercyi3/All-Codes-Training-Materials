package com.ia.reviewapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InnovativeReviewAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
