package com.javafullstack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectingFrontendToBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
