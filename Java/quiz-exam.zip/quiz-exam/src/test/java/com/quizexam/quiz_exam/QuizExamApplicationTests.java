package com.quizexam.quiz_exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
