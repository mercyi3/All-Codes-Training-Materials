package com.javafullstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConnectingFrontendToBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConnectingFrontendToBackendApplication.class, args);
	}

}
