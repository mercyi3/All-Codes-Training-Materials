package com.login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SignInSignUpApplicationTests {

	@Test
	void contextLoads() {
	}

}
